import os
import cv2
import pytesseract
import re
from colorama import Fore, Style
from tqdm import tqdm
import difflib
import csv
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import threading
import sys

tesseract_location = 'C:/Program Files/Tesseract-OCR/tesseract.exe'
pytesseract.pytesseract.tesseract_cmd = tesseract_location

def is_built_exe():
    return getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS')

def find_most_common_char(pos, strings):
    char_count = {}
    for s in strings:
        if pos < len(s):
            char = s[pos]
            char_count[char] = char_count.get(char, 0) + 1
    
    max_count = -1
    most_common_char = None
    for char, count in char_count.items():
        if count > max_count:
            max_count = count
            most_common_char = char
    return most_common_char

def reconstruct_string(strings_list):
    max_length = max(len(s) for s in strings_list)
    reconstructed_str = ""

    for i in range(max_length):
        most_common_char = find_most_common_char(i, strings_list)
        if most_common_char:
            reconstructed_str += most_common_char

    return reconstructed_str

# List of regions of interest (ROIs) in (x, y, width, height, numbers_only) format
ROIs = [
    # Team 1
    # Player 1
    (117, 100, 176, 35, False), # Name
    (347, 109, 58, 34, True),
    (405, 109, 54, 34, True),
    (459, 109, 55, 34, True),
    (514, 109, 112, 34, True),
    (626, 109, 101, 34, True),
    (727, 109, 95, 34, True),
    # Player 2
    (117, 163, 176, 35, False), # Name
    (347, 172, 58, 34, True),
    (405, 172, 54, 34, True),
    (459, 172, 55, 34, True),
    (514, 172, 112, 34, True),
    (626, 172, 101, 34, True),
    (727, 172, 95, 34, True),
    # Player 3
    (117, 226, 176, 35, False), # Name
    (347, 235, 58, 34, True),
    (405, 235, 54, 34, True),
    (459, 235, 55, 34, True),
    (514, 235, 112, 34, True),
    (626, 235, 101, 34, True),
    (727, 235, 95, 34, True),
    # Player 4
    (117, 288, 176, 35, False), # Name
    (347, 295, 58, 34, True),
    (405, 295, 54, 34, True),
    (459, 295, 55, 34, True),
    (514, 295, 112, 34, True),
    (626, 295, 101, 34, True),
    (727, 295, 95, 34, True),
    # Player 5
    (117, 349, 176, 35, False), # Name
    (347, 357, 58, 34, True),
    (405, 357, 54, 34, True),
    (459, 357, 55, 34, True),
    (514, 357, 112, 34, True),
    (626, 357, 101, 34, True),
    (727, 357, 95, 34, True),

    # Team 2
    # Player 6
    (69, 100+320, 176, 35, False), # Name
    (347, 109+320, 58, 34, True),
    (405, 109+320, 54, 34, True),
    (459, 109+320, 55, 34, True),
    (514, 109+320, 112, 34, True),
    (626, 109+320, 101, 34, True),
    (727, 109+320, 95, 34, True),
    # Player 7
    (69, 163+320, 176, 35, False), # Name
    (347, 172+320, 58, 34, True),
    (405, 172+320, 54, 34, True),
    (459, 172+320, 55, 34, True),
    (514, 172+320, 112, 34, True),
    (626, 172+320, 101, 34, True),
    (727, 172+320, 95, 34, True),
    # Player 8
    (69, 226+320, 176, 35, False), # Name
    (347, 235+320, 58, 34, True),
    (405, 235+320, 54, 34, True),
    (459, 235+320, 55, 34, True),
    (514, 235+320, 112, 34, True),
    (626, 235+320, 101, 34, True),
    (727, 235+320, 95, 34, True),
    # Player 9
    (69, 288+320, 176, 35, False), # Name
    (347, 295+320, 58, 34, True),
    (405, 295+320, 54, 34, True),
    (459, 295+320, 55, 34, True),
    (514, 295+320, 112, 34, True),
    (626, 295+320, 101, 34, True),
    (727, 295+320, 95, 34, True),
    # Player 10
    (69, 349+320, 176, 35, False), # Name
    (347, 357+320, 58, 34, True),
    (405, 357+320, 54, 34, True),
    (459, 357+320, 55, 34, True),
    (514, 357+320, 112, 34, True),
    (626, 357+320, 101, 34, True),
    (727, 357+320, 95, 34, True),

    # Other
    # Mode/Map
    (114, 9, 519, 26, False),
    # Time
    (179, 40, 86, 27, True),
]


# Directory containing the images
image_directory = './Data'

# Define the regex pattern for the image file name
pattern = re.compile(r'data-\((\d{1,3})-(\d{1,3})-(W|L|X)\)\.png', re.IGNORECASE)

# Set data
data = {}

# Filter the image files and store them in a list
image_files = [file_name for file_name in os.listdir(image_directory) if pattern.match(file_name)]

# Sort the image files by modification date
image_files.sort(key=lambda x: os.path.getmtime(os.path.join(image_directory, x)))

def get_colors():
    """Get the color ranges for the chat types."""
    # Colors
    time_color = (231, 99, 22)

    # Ranges
    h_range = 10
    s_range = 30
    v_range = 30

    # Convert Time
    time_rgb_color_reshape = np.array([[[*time_color]]], dtype=np.uint8)
    time_hsv_color = cv2.cvtColor(time_rgb_color_reshape, cv2.COLOR_RGB2HSV)[0][0]
    time_lower_hsv_color = np.array([time_hsv_color[0] - h_range, time_hsv_color[1] - s_range, time_hsv_color[2] - v_range])
    time_upper_hsv_color = np.array([time_hsv_color[0] + h_range, time_hsv_color[1] + s_range, time_hsv_color[2] + v_range])
    time_lower_hsv_color = np.clip(time_lower_hsv_color, [0, 0, 0], [179, 255, 255])
    time_upper_hsv_color = np.clip(time_upper_hsv_color, [0, 0, 0], [179, 255, 255])

    return (time_lower_hsv_color, time_upper_hsv_color)

def mask_time(img_hsv):
    time_hsv_range = get_colors()

    time_mask = cv2.inRange(img_hsv, time_hsv_range[0], time_hsv_range[1])

    return time_mask


def process_image_file(file_name):
    match = pattern.match(file_name)
    if match:
        x, y, z = match.groups()
        if z != "X":
            return
        x, y = int(x), int(y)

        # Initialize lists to store player names for the current match
        if x not in data:
            data[x] = {}
            data[x]['found_names'] = {
                0: [],
                1: [],
                2: [],
                3: [],
                4: [],
                5: [],
                6: [],
                7: [],
                8: [],
                9: []
            }
            data[x]['found_mode_maps'] = []
        
        found_names = data[x]['found_names']
        found_mode_maps = data[x]['found_mode_maps']

        # Read the image using OpenCV
        image_path = os.path.join(image_directory, file_name)
        image = cv2.imread(image_path)

        # Process each region of interest (ROI)
        roi_data = []
        for roi in ROIs:
            x_roi, y_roi, w, h, numbers_only = roi
            cropped_image = image
            if (x_roi, y_roi) == (179, 40):
                image_hsv = cv2.cvtColor(image[y_roi:y_roi + h, x_roi:x_roi + w], cv2.COLOR_BGR2HSV)
                cropped_image = mask_time(image_hsv)
            else:
                cropped_image = image[y_roi:y_roi + h, x_roi:x_roi + w]

            # Set the config according to the numbers_only flag
            config = '--psm 7 -c tessedit_char_whitelist=:,O0123456789' if numbers_only else '--psm 7'

            # Use pytesseract to perform OCR on the cropped image
            ocr_result = pytesseract.image_to_string(cropped_image, config=config)
            if numbers_only:
                ocr_result = ocr_result.replace("O", "0")
                ocr_result = ocr_result.replace(" ", "")
            ocr_result = ocr_result.strip()
            ocr_result = ocr_result.replace(",", "")
            if ocr_result == "":
                ocr_result = "0"
            roi_data.append(ocr_result)

        # Organize the data into the data structure
        if x not in data:
            data[x] = {}
        data[x][y] = {z: roi_data}

        # Store player names for reconstruction
        found_names[0].append(roi_data[7*0])
        found_names[1].append(roi_data[7*1])
        found_names[2].append(roi_data[7*2])
        found_names[3].append(roi_data[7*3])
        found_names[4].append(roi_data[7*4])
        found_names[5].append(roi_data[7*5])
        found_names[6].append(roi_data[7*6])
        found_names[7].append(roi_data[7*7])
        found_names[8].append(roi_data[7*8])
        found_names[9].append(roi_data[7*9])

        # Store mode/map for reconstruction
        found_mode_maps.append(roi_data[70])

# Create a list to store the threads
threads = []

# Set the maximum number of concurrent threads
max_threads = 2

# Create a Semaphore to limit the number of concurrent threads
semaphore = threading.Semaphore(max_threads)

def process_image_file_with_semaphore(image_file):
    with semaphore:
        process_image_file(image_file)

# Create and start threads for each image file
for image_file in image_files:
    t = threading.Thread(target=process_image_file_with_semaphore, args=(image_file,))
    t.start()
    threads.append(t)

# Wait for all threads to finish
for t in threads:
    t.join()

for x, match_data in data.items():
    # Reconstruct player names for the current match
    p0_name = reconstruct_string(match_data['found_names'][0])
    p1_name = reconstruct_string(match_data['found_names'][1])
    p2_name = reconstruct_string(match_data['found_names'][2])
    p3_name = reconstruct_string(match_data['found_names'][3])
    p4_name = reconstruct_string(match_data['found_names'][4])
    p5_name = reconstruct_string(match_data['found_names'][5])
    p6_name = reconstruct_string(match_data['found_names'][6])
    p7_name = reconstruct_string(match_data['found_names'][7])
    p8_name = reconstruct_string(match_data['found_names'][8])
    p9_name = reconstruct_string(match_data['found_names'][9])

    # Reconstruct mode/map for the current match
    mode_map = reconstruct_string(match_data['found_mode_maps'])

    # Set players in the data object
    match_data['reconstructed_names'] = {
        0: p0_name,
        1: p1_name,
        2: p2_name,
        3: p3_name,
        4: p4_name,
        5: p5_name,
        6: p6_name,
        7: p7_name,
        8: p8_name,
        9: p9_name,
    }

    # Set mode/map in the data object
    match_data['reconstructed_mode'] = mode_map.split("-")[0].strip()
    #match_data['reconstructed_map'] = mode_map.split("-")[1].strip()[14::].strip()

# Print the organized data in a user-friendly format
with open('pred_data.csv', 'w', newline='') as machine_learning_file:
    csv_writer_ml = csv.writer(machine_learning_file)
    csv_writer_ml.writerow(['Set', 'Outcome', 'Mode', 'Time', 'Team_Index', 'Player_Index', 'Eliminations', 'Assists', 'Deaths', 'Damage', 'Healing', 'Mitigated'])

    set_index = 0
    sc_index = 0
    for x, match_data in data.items():
        sc_index = 0
        print("\n")
        # Get the reconstructed names
        p0_name = match_data['reconstructed_names'][0]
        p1_name = match_data['reconstructed_names'][1]
        p2_name = match_data['reconstructed_names'][2]
        p3_name = match_data['reconstructed_names'][3]
        p4_name = match_data['reconstructed_names'][4]
        p5_name = match_data['reconstructed_names'][5]
        p6_name = match_data['reconstructed_names'][6]
        p7_name = match_data['reconstructed_names'][7]
        p8_name = match_data['reconstructed_names'][8]
        p9_name = match_data['reconstructed_names'][9]

        # Get the reconstructed mode/map
        mode = match_data['reconstructed_mode']
        #map = match_data['reconstructed_map']

        # Filter out non-integer keys and sort the remaining items
        sorted_screenshots = sorted((k, v) for k, v in match_data.items() if isinstance(k, int))
        sorted_screenshots = sorted_screenshots[len(sorted_screenshots) % 2::]

        prev_time = -1

        for y, screenshot_data in sorted_screenshots:
            if len(sorted_screenshots) < 2:
                break
            if sc_index >= len(sorted_screenshots) - (len(sorted_screenshots) % 2):
                break
            # Set the text color based on the screenshot number
            textcolor = Fore.GREEN if int(y) % 2 == 0 else Fore.YELLOW
            for z, roi_data in screenshot_data.items():
                # Add rows to the ml data CSV file
                if z == "X":
                    time_seconds = 0
                    if ":" in roi_data[71] and len(roi_data[71].split(":")) >= 2:
                        time_seconds = int(roi_data[71].split(":")[0]) * 60 + int(roi_data[71].split(":")[1])
                    if time_seconds >= 30 and time_seconds != prev_time:
                        csv_writer_ml.writerow([set_index, z, mode, time_seconds, 0, 0, roi_data[1].replace(":", ""), roi_data[2].replace(":", ""), roi_data[3].replace(":", ""), roi_data[4].replace(":", ""), roi_data[5].replace(":", ""), roi_data[6].replace(":", "")])
                        csv_writer_ml.writerow([set_index, z, mode, time_seconds, 0, 1, roi_data[8].replace(":", ""), roi_data[9].replace(":", ""), roi_data[10].replace(":", ""), roi_data[11].replace(":", ""), roi_data[12].replace(":", ""), roi_data[13].replace(":", "")])
                        csv_writer_ml.writerow([set_index, z, mode, time_seconds, 0, 2, roi_data[15].replace(":", ""), roi_data[16].replace(":", ""), roi_data[17].replace(":", ""), roi_data[18].replace(":", ""), roi_data[19].replace(":", ""), roi_data[20].replace(":", "")])
                        csv_writer_ml.writerow([set_index, z, mode, time_seconds, 0, 3, roi_data[22].replace(":", ""), roi_data[23].replace(":", ""), roi_data[24].replace(":", ""), roi_data[25].replace(":", ""), roi_data[26].replace(":", ""), roi_data[27].replace(":", "")])
                        csv_writer_ml.writerow([set_index, z, mode, time_seconds, 0, 4, roi_data[29].replace(":", ""), roi_data[30].replace(":", ""), roi_data[31].replace(":", ""), roi_data[32].replace(":", ""), roi_data[33].replace(":", ""), roi_data[34].replace(":", "")])
                        csv_writer_ml.writerow([set_index, z, mode, time_seconds, 1, 0, roi_data[36].replace(":", ""), roi_data[37].replace(":", ""), roi_data[38].replace(":", ""), roi_data[39].replace(":", ""), roi_data[40].replace(":", ""), roi_data[41].replace(":", "")])
                        csv_writer_ml.writerow([set_index, z, mode, time_seconds, 1, 1, roi_data[43].replace(":", ""), roi_data[44].replace(":", ""), roi_data[45].replace(":", ""), roi_data[46].replace(":", ""), roi_data[47].replace(":", ""), roi_data[48].replace(":", "")])
                        csv_writer_ml.writerow([set_index, z, mode, time_seconds, 1, 2, roi_data[50].replace(":", ""), roi_data[51].replace(":", ""), roi_data[52].replace(":", ""), roi_data[53].replace(":", ""), roi_data[54].replace(":", ""), roi_data[55].replace(":", "")])
                        csv_writer_ml.writerow([set_index, z, mode, time_seconds, 1, 3, roi_data[57].replace(":", ""), roi_data[58].replace(":", ""), roi_data[59].replace(":", ""), roi_data[60].replace(":", ""), roi_data[61].replace(":", ""), roi_data[62].replace(":", "")])
                        csv_writer_ml.writerow([set_index, z, mode, time_seconds, 1, 4, roi_data[64].replace(":", ""), roi_data[65].replace(":", ""), roi_data[66].replace(":", ""), roi_data[67].replace(":", ""), roi_data[68].replace(":", ""), roi_data[69].replace(":", "")])
                        set_index += 1
                        sc_index += 1
                        prev_time = time_seconds
        #print(table)