# Import the necessary packages
from consolemenu import *
from consolemenu.items import *
import json
from concurrent.futures import ThreadPoolExecutor, wait
from ctypes.wintypes import RECT, DWORD
from ctypes import windll
import ctypes.wintypes
import logging
import time
import win32ui
import win32gui
import win32process
import psutil
import os
from pynput import keyboard
import pyautogui
import cv2
import numpy as np
import pandas as pd
import numpy as np
from tensorflow.keras.models import load_model
import pickle
import os
import cv2
import pytesseract
import re
from colorama import Fore, Style
from tqdm import tqdm
import difflib
import csv
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import subprocess
import winsound
import sys

is_training = False
previous_predictions = dict()

def is_built_exe():
    return getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS')

os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '1'
numerical_columns = ['Time', 'Eliminations', 'Assists', 'Deaths', 'Damage', 'Healing', 'Mitigated']
SPECIFIC_EXE_NAME = "Overwatch.exe"
CSIDL_PERSONAL = 5       # My Documents
SHGFP_TYPE_CURRENT = 0   # Get current, not default value
documents_buffer= ctypes.create_unicode_buffer(ctypes.wintypes.MAX_PATH)
ctypes.windll.shell32.SHGetFolderPathW(None, CSIDL_PERSONAL, None, SHGFP_TYPE_CURRENT, documents_buffer)
previous_process_name = None
process_active = False
alt_pressed = False
tab_pressed = False
current_match = 0
chatopen = False
screenshot_taken = -1

# Load the saved model
model = load_model("trained_model.h5")

# Load the MinMaxScaler
with open("scaler.pkl", "rb") as f:
  scaler = pickle.load(f)

def reshape_data(df, n_samples, n_sets_per_sample=2, n_players=10, n_stats=7):
    X = np.zeros((n_samples, n_sets_per_sample, n_players, n_stats))
    y = np.zeros((n_samples, 1))

    for i in range(n_samples):
        for j in range(n_sets_per_sample):
            X[i, j, :, :] = df.loc[(df['Set'] == i * n_sets_per_sample + j) & (df['Player_Index'] < n_players), numerical_columns].values
        y[i, 0] = df.loc[df['Set'] == i * n_sets_per_sample, 'Outcome'].values[0]

    return X, y

def load_and_preprocess_new_data(csv_path, scaler, n_samples, n_sets_per_sample=3, n_players=10, n_stats=7):
    df_orig = pd.read_csv(csv_path, na_values='?', skipinitialspace=True)
    df = pd.read_csv(csv_path, na_values='?', skipinitialspace=True)
    df['Outcome'] = df['Outcome'].map({'W': 1, 'L': 0, 'X': -1})
    df[numerical_columns] = scaler.transform(df[numerical_columns])
    n_sets = df['Set'].nunique()
    n_sets_per_sample = 2
    n_samples = n_sets // n_sets_per_sample
    X, y = reshape_data(df, n_samples=n_samples)
    return X, df_orig

def predict_now():
  global screenshot_taken, previous_predictions
  print("Predicting...")
  frequency = 300  # Set Frequency To 2500 Hertz
  duration = 150  # Set Duration To 1000 ms == 1 second
  winsound.Beep(frequency, duration)

  if is_built_exe():
    pr = subprocess.Popen(["cmd", "/c", "dataformatter_pred.exe"])
    pr.wait()
  else:
    subprocess.run(["python", "dataformatter_pred.py"])
    # Load the MinMaxScaler
  with open("scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

  # Load and preprocess new data
  #new_data_csv_path = "single_set.csv"
  new_data_csv_path = "pred_data.csv"
  n_samples = 10  # Update this value based on the number of samples in your new data
  X_new, df_orig = load_and_preprocess_new_data(new_data_csv_path, scaler, n_samples)

  # Make predictions
  predictions = model.predict(X_new, verbose=0)
  print("\n")
  # Print previous predictions
  for key, value in previous_predictions.items():
    print("Time: " + str(value[0] // 60) + ":" + str(value[0] % 60) + " - " + str(value[1] // 60) + ":" + str(value[1] % 60))
    print("Chance of Winning: " + str(round(value[2] * 1000) / 10) + "%")
  for idx, prediction in enumerate(predictions):
    timeval_start = df_orig['Time'].values[idx * 20 + 1]
    timeval_end = df_orig['Time'].values[idx * 20 + 10]
    add_text_start = ""
    add_text_end = ""
    if timeval_start % 60 < 10:
      add_text_start = "0"
    if timeval_end % 60 < 10:
      add_text_end = "0"
    pred = prediction[0]
    previous_predictions[(timeval_start, timeval_end)] = [timeval_start, timeval_end, pred]
    print("Time: " + str(timeval_start // 60) + ":" + add_text_start + str(timeval_start % 60) + " - " + str(timeval_end // 60) + ":" + add_text_end + str(timeval_end % 60))
    print("Chance of Winning: " + str(round(pred * 1000) / 10) + "%")
  print("\n")
  frequency = 300  # Set Frequency To 2500 Hertz
  duration = 150  # Set Duration To 1000 ms == 1 second
  winsound.Beep(frequency, duration)
  wipe_data(True)
  return

def get_colors():
  # Colors
  team_color = (1, 193, 253)
  match_color = (255, 152, 67)
  group_color = (0, 217, 8)
  direct_color = (244, 128, 255)
  properimg_color = (218, 218, 218)


  # Ranges
  h_range = 10
  s_range = 30
  v_range = 30

  # Convert Team
  team_rgb_color_reshape = np.array([[[*team_color]]], dtype=np.uint8)
  team_hsv_color = cv2.cvtColor(team_rgb_color_reshape, cv2.COLOR_RGB2HSV)[0][0]
  team_lower_hsv_color = np.array([team_hsv_color[0] - h_range, team_hsv_color[1] - s_range, team_hsv_color[2] - v_range])
  team_upper_hsv_color = np.array([team_hsv_color[0] + h_range, team_hsv_color[1] + s_range, team_hsv_color[2] + v_range])
  team_lower_hsv_color = np.clip(team_lower_hsv_color, [0, 0, 0], [179, 255, 255])
  team_upper_hsv_color = np.clip(team_upper_hsv_color, [0, 0, 0], [179, 255, 255])

  # Convert Match
  match_rgb_color_reshape = np.array([[[*match_color]]], dtype=np.uint8)
  match_hsv_color = cv2.cvtColor(match_rgb_color_reshape, cv2.COLOR_RGB2HSV)[0][0]
  match_lower_hsv_color = np.array([match_hsv_color[0] - h_range, match_hsv_color[1] - s_range, match_hsv_color[2] - v_range])
  match_upper_hsv_color = np.array([match_hsv_color[0] + h_range, match_hsv_color[1] + s_range, match_hsv_color[2] + v_range])
  match_lower_hsv_color = np.clip(match_lower_hsv_color, [0, 0, 0], [179, 255, 255])
  match_upper_hsv_color = np.clip(match_upper_hsv_color, [0, 0, 0], [179, 255, 255])

  # Convert Group
  group_rgb_color_reshape = np.array([[[*group_color]]], dtype=np.uint8)
  group_hsv_color = cv2.cvtColor(group_rgb_color_reshape, cv2.COLOR_RGB2HSV)[0][0]
  group_lower_hsv_color = np.array([group_hsv_color[0] - h_range, group_hsv_color[1] - s_range, group_hsv_color[2] - v_range])
  group_upper_hsv_color = np.array([group_hsv_color[0] + h_range, group_hsv_color[1] + s_range, group_hsv_color[2] + v_range])
  group_lower_hsv_color = np.clip(group_lower_hsv_color, [0, 0, 0], [179, 255, 255])
  group_upper_hsv_color = np.clip(group_upper_hsv_color, [0, 0, 0], [179, 255, 255])

  # Convert Direct
  direct_rgb_color_reshape = np.array([[[*direct_color]]], dtype=np.uint8)
  direct_hsv_color = cv2.cvtColor(direct_rgb_color_reshape, cv2.COLOR_RGB2HSV)[0][0]
  direct_lower_hsv_color = np.array([direct_hsv_color[0] - h_range, direct_hsv_color[1] - s_range, direct_hsv_color[2] - v_range])
  direct_upper_hsv_color = np.array([direct_hsv_color[0] + h_range, direct_hsv_color[1] + s_range, direct_hsv_color[2] + v_range])
  direct_lower_hsv_color = np.clip(direct_lower_hsv_color, [0, 0, 0], [179, 255, 255])
  direct_upper_hsv_color = np.clip(direct_upper_hsv_color, [0, 0, 0], [179, 255, 255])

  # Convert Properimg
  properimg_rgb_color_reshape = np.array([[[*properimg_color]]], dtype=np.uint8)
  properimg_hsv_color = cv2.cvtColor(properimg_rgb_color_reshape, cv2.COLOR_RGB2HSV)[0][0]
  properimg_lower_hsv_color = np.array([properimg_hsv_color[0] - h_range, properimg_hsv_color[1] - s_range, properimg_hsv_color[2] - v_range])
  properimg_upper_hsv_color = np.array([properimg_hsv_color[0] + h_range, properimg_hsv_color[1] + s_range, properimg_hsv_color[2] + v_range])
  properimg_lower_hsv_color = np.clip(properimg_lower_hsv_color, [0, 0, 0], [179, 255, 255])
  properimg_upper_hsv_color = np.clip(properimg_upper_hsv_color, [0, 0, 0], [179, 255, 255])

  return (team_lower_hsv_color, team_upper_hsv_color), (match_lower_hsv_color, match_upper_hsv_color), (group_lower_hsv_color, group_upper_hsv_color), (direct_lower_hsv_color, direct_upper_hsv_color), (properimg_lower_hsv_color, properimg_upper_hsv_color)

def check_chat_open(img_hsv, w, h):
  team_hsv_range, match_hsv_range, group_hsv_range, direct_hsv_range, properimg_hsv_range = get_colors()

  team_mask = cv2.inRange(img_hsv, team_hsv_range[0], team_hsv_range[1])
  match_mask = cv2.inRange(img_hsv, match_hsv_range[0], match_hsv_range[1])
  group_mask = cv2.inRange(img_hsv, group_hsv_range[0], group_hsv_range[1])
  direct_mask = cv2.inRange(img_hsv, direct_hsv_range[0], direct_hsv_range[1])

  chatopen_sample_pos1 = (round(w * (46 / 145)), round(h * (43 / 474)))
  chatopen_sample_pos2 = (round(w * (46 / 145)), round(h * (434 / 474)))

  # Add Group Chat Check
  if team_mask[chatopen_sample_pos1[1], chatopen_sample_pos1[0]] == 255:
    return True, team_mask, match_mask, group_mask, direct_mask
  elif match_mask[chatopen_sample_pos1[1], chatopen_sample_pos1[0]] == 255:
    return True, team_mask, match_mask, group_mask, direct_mask
  elif group_mask[chatopen_sample_pos1[1], chatopen_sample_pos1[0]] == 255:
    return True, team_mask, match_mask, group_mask, direct_mask
  elif direct_mask[chatopen_sample_pos1[1], chatopen_sample_pos1[0]] == 255:
    return True, team_mask, match_mask, group_mask, direct_mask
  
  if team_mask[chatopen_sample_pos2[1], chatopen_sample_pos2[0]] == 255:
    return True, team_mask, match_mask, group_mask, direct_mask
  elif match_mask[chatopen_sample_pos2[1], chatopen_sample_pos2[0]] == 255:
    return True, team_mask, match_mask, group_mask, direct_mask
  elif group_mask[chatopen_sample_pos2[1], chatopen_sample_pos2[0]] == 255:
    return True, team_mask, match_mask, group_mask, direct_mask
  elif direct_mask[chatopen_sample_pos2[1], chatopen_sample_pos2[0]] == 255:
    return True, team_mask, match_mask, group_mask, direct_mask

  return False, team_mask, match_mask, group_mask, direct_mask

def check_properimg(img_hsv, w, h):
  team_hsv_range, match_hsv_range, group_hsv_range, direct_hsv_range, properimg_hsv_range = get_colors()

  white_mask = cv2.inRange(img_hsv, properimg_hsv_range[0], properimg_hsv_range[1])

  scoreboard_sample_pos1 = (round(w * (12 / 826)), round(h * (90 / 726)))

  # Add Group Chat Check
  if white_mask[scoreboard_sample_pos1[1], scoreboard_sample_pos1[0]] == 255:
    return True, white_mask

  return False, white_mask

def place_image(img_collage, img, x, y):
  h, w, _ = img.shape
  img_collage[y:y+h, x:x+w] = img

def process_screenshots(screenshot_time, screenshot_t1, screenshot_t2, screen_w, screen_h, special=False):
  global current_match
  screenshot_time_cv = cv2.cvtColor(np.array(screenshot_time), cv2.COLOR_RGB2BGR)
  screenshot_t1_cv = cv2.cvtColor(np.array(screenshot_t1), cv2.COLOR_RGB2BGR)
  screenshot_t2_cv = cv2.cvtColor(np.array(screenshot_t2), cv2.COLOR_RGB2BGR)
  img_collage = np.zeros((round((968 / 2560) * screen_w), round((1102 / 1440) * screen_h), 3), np.uint8)
  place_image(img_collage, screenshot_time_cv, 0, 0)
  place_image(img_collage, screenshot_t1_cv, 0, round((116 / 1440) * screen_h))
  place_image(img_collage, screenshot_t2_cv, 0, round((543 / 1440) * screen_h))
  
  dim = (826, 726)
  resized = cv2.resize(img_collage, dim, interpolation = cv2.INTER_LANCZOS4)
  #scoreboard_correct, white_mask = check_properimg(cv2.cvtColor(resized, cv2.COLOR_BGR2HSV), width, height)
  
  image_save_path = "./Data"
  isExist = os.path.exists(image_save_path)
  if not isExist:
    os.makedirs(image_save_path)
  file_list = os.listdir(image_save_path)
  file_list.sort(key=lambda x: os.path.getmtime(os.path.join(image_save_path, x)))
  highest_num = 0
  matchnum = -1
  for f in file_list:
    if os.path.isfile(image_save_path+'/'+f) and "(" in f and ")" in f:
      matchnum = int(f.split("(")[1].split(")")[0].split("-")[0])
      screenshotnum = int(f.split("(")[1].split(")")[0].split("-")[1])
      outcome = f.split("(")[1].split(")")[0].split("-")[2]
      if screenshotnum > highest_num and current_match == matchnum:
        highest_num = screenshotnum
  if matchnum != current_match:
    highest_num = 0
    current_match = matchnum+1
  logging.info("Saving data screenshot...")
  frequency = 300  # Set Frequency To 2500 Hertz
  duration = 150  # Set Duration To 1000 ms == 1 second
  winsound.Beep(frequency, duration)
  highest_num += 1
  cv2.imwrite(image_save_path + "/data-(" + str(current_match) + "-" + str(highest_num) + "-" + "X).png", resized)
  return

def try_capture():
  global process_active, alt_pressed, tab_pressed, chatopen, screenshot_taken
  if tab_pressed and process_active and (not alt_pressed):
    time.sleep(0.05)
    hwnd = win32gui.FindWindow(None, SPECIFIC_EXE_NAME[:-4])
    if hwnd == 0:
      logging.warning("Could not find the 'Overwatch' window.")
      return
    
    left, top, right, bot = win32gui.GetWindowRect(hwnd)
    screen_w = right - left
    screen_h = bot - top

    # Screenshot Chat
    sc_left = round((15 / 2560) * screen_w)
    sc_top = round((865 / 1440) * screen_h)
    sc_w = round((145 / 2560) * screen_w)
    sc_h = round((474 / 1440) * screen_h)
    screenshot_chat = pyautogui.screenshot(region=(sc_left, sc_top, sc_w, sc_h))
    
    img_hsv_chat = cv2.cvtColor(cv2.cvtColor(np.array(screenshot_chat), cv2.COLOR_RGB2BGR), cv2.COLOR_BGR2HSV)

    chatopen, team_mask, match_mask, group_mask, direct_mask = check_chat_open(img_hsv_chat, sc_w, sc_h)

    if chatopen:
      logging.warning("Chat is open, can't capture.")
      return
    if (time.time() - 20) < screenshot_taken:
      logging.warning("Tab pressed again too soon, can't capture.")
      return
    else:
      # Screenshot map/time/mode
      sc_left = round((11 / 2560) * screen_w)
      sc_top = round((30 / 1440) * screen_h)
      sc_w = round((845 / 2560) * screen_w)
      sc_h = round((116 / 1440) * screen_h)
      screenshot_time = pyautogui.screenshot(region=(sc_left, sc_top, sc_w, sc_h))

      # Screenshot Team 1
      sc_left = round((452 / 2560) * screen_w)
      sc_top = round((249 / 1440) * screen_h)
      sc_w = round((1102 / 2560) * screen_w)
      sc_h = round((427 / 1440) * screen_h)
      screenshot_t1 = pyautogui.screenshot(region=(sc_left, sc_top, sc_w, sc_h))

      # Screenshot Team 2
      sc_left = round((452 / 2560) * screen_w)
      sc_top = round((810 / 1440) * screen_h)
      sc_w = round((1102 / 2560) * screen_w)
      sc_h = round((425 / 1440) * screen_h)
      screenshot_t2 = pyautogui.screenshot(region=(sc_left, sc_top, sc_w, sc_h))

      screenshot_taken = time.time()
      process_screenshots(screenshot_time, screenshot_t1, screenshot_t2, screen_w, screen_h, False)
  return

def key_press_listener(e, executor, futures):
  global alt_pressed, tab_pressed

  if hasattr(e, "name"):
    if e.name == 'alt_l':
      alt_pressed = True
    if e.name == 'tab':
      tab_pressed = True
      futures.append(executor.submit(try_capture))
  return

def increment_match(outcome):
  global current_match
  image_save_path = "./Data"
  isExist = os.path.exists(image_save_path)
  if not isExist:
    os.makedirs(image_save_path)
  file_list = os.listdir(image_save_path)
  should_increment = False
  for f in file_list:
    if os.path.isfile(image_save_path+'/'+f) and "(" in f and ")" in f:
      matchnum = int(f.split("(")[1].split(")")[0].split("-")[0])
      if matchnum > current_match:
        current_match = matchnum
  for f in file_list:
    if os.path.isfile(image_save_path+'/'+f) and "(" in f and ")" in f:
      matchnum = int(f.split("(")[1].split(")")[0].split("-")[0])
      if matchnum == current_match:
          if outcome == "D" and "-X" in f:
            logging.info("Discarding Match Data: " + f)
            os.remove(image_save_path + "/" + f)
          if "data" in f and "-X" in f:
            should_increment = True
            screenshotnum = int(f.split("(")[1].split(")")[0].split("-")[1])
            os.rename(image_save_path + "/" + f, image_save_path + "/data-(" + str(matchnum) + "-" + str(screenshotnum) + "-" + outcome + ").png")
  if should_increment:
    logging.info("Incrementing Match: " + ("Loss" if outcome == "L" else "Win" if outcome == "W" else "Discard"))
    current_match += 1

def wipe_data(leave_one=False):
  global current_match, previous_predictions, current_match
  image_save_path = "./Data"
  isExist = os.path.exists(image_save_path)
  if not isExist:
    os.makedirs(image_save_path)
  file_list = os.listdir(image_save_path)
  file_list.sort(key=lambda x: os.path.getmtime(os.path.join(image_save_path, x)))
  if leave_one:
    file_list = file_list[:-1]
  for f in file_list:
    os.remove(image_save_path + "/" + f)
  current_match = 0
  if not leave_one:
    previous_predictions = previous_predictions.clear()

def key_release_listener(e, executor, futures):
  global alt_pressed, tab_pressed, chatopen

  if hasattr(e, "name"):
    if e.name == 'alt_l':
      alt_pressed = False
    if e.name == 'tab':
      tab_pressed = False
    if not chatopen and process_active:
      if e.name == 'left':
        if not is_built_exe() and is_training:
          increment_match("L")
      if e.name == 'right':
        if not is_built_exe() and is_training:
          increment_match("W")
      if e.name == 'down':
        if not is_built_exe() and is_training:
          increment_match("D")
        else:
          wipe_data(False)
      if e.name == 'up':
        futures.append(executor.submit(predict_now))
  return

def get_active_process_name():
    try:
        hwnd = win32gui.GetForegroundWindow()
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        process = psutil.Process(pid)
        return process.exe().split('\\')[-1]
    except Exception:
        return None

def loop_process_scan(collecting_data):
  global process_active, previous_process_name
  logging.info("Now Collecting Data.")

  while collecting_data:
    active_process_name = get_active_process_name()

    if active_process_name == SPECIFIC_EXE_NAME:
      process_active = True
    else:
      process_active = False

    if active_process_name != previous_process_name:
      print("Active process: %s" % active_process_name)

    previous_process_name = active_process_name
    time.sleep(0.3)

def start_listeners(executor, futures):
  with keyboard.Listener(on_press=lambda e: key_press_listener(e, executor, futures), on_release=lambda e: key_release_listener(e, executor, futures)) as listener:
    listener.join()

def start_tool():
  # Set up logging
  logging.basicConfig(level=logging.INFO, format='%(asctime)s: %(message)s')

  # Start collecting data
  collecting_data = True
  futures = []

  # Create ThreadPoolExecutor without the with statement
  executor = ThreadPoolExecutor(5)

  # Submit tasks to the executor
  futures.append(executor.submit(loop_process_scan, collecting_data))
  futures.append(executor.submit(start_listeners, executor, futures))

  # Wait for all tasks to complete
  wait(futures)

  # Manually shut down the executor
  executor.shutdown()

def export_dev_data():
  if is_built_exe():
    pr = subprocess.Popen(["cmd", "/c", "dataformatter_train.exe"])
    pr.wait()
  else:
    subprocess.run(["python", "dataformatter_train.py"])

# Create the menu
menu = ConsoleMenu("Overwatch Assistant", "A tool for informing gameplay.")
function_item_start = FunctionItem("(User) Start Tool", start_tool)
function_item_dev = FunctionItem("(Developer) Format Data", export_dev_data)
menu.append_item(function_item_start)
menu.append_item(function_item_dev)
menu.show(show_exit_option=False)

#roiFile = open('./roi.json')
#rois = json.load(roiFile)
#roiFile.close()